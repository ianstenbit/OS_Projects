#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char** argv){
	
	int i;
	for(i = 0; argc > 1 && i < strlen(argv[1]); i++)
		if(!isdigit(argv[1][i])){
			argc = 1;
			break;
		}
	
	if(argc == 1)
		printf("Huh?\n");
	else{	

		i = atoi(argv[1]);
		if(i > 12)
			printf("Overflow\n");
		else
			printf("%i\n", factorial(i));

	}

	return 0;


}

int factorial(int i){
	if(i == 0 || i == 1) return i;
	return i * factorial(i-1);
}
